using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
using System.IO;
using System.Threading;
using ThinkGearNET;
using System.Collections;

namespace cerebrum
{
    public partial class Flive : Form
    {
        private ThinkGearWrapper _thinkGearWrapper = new ThinkGearWrapper();
        public int oldVatt = -1;
        public int oldVmed = -1;
        public int oldVa1 = -1;
        public int oldVa2 = -1;
        public int oldVb1 = -1;
        public int oldVb2 = -1;
        public int oldVg1 = -1;
        public int oldVg2 = -1;
        public int oldVde = -1;
        public int oldVth = -1;
        public int r = 0;
        public int interv = 0;
        public string ora = "";

        //public int altFin = 100;
        public int moduloA1 = 350000 / 100;
        public int moduloA2 = 456000 / 100;
        int moduloB1 = 419000 / 100;
        int moduloB2 = 373000 / 100;
        int moduloG1 = 154000 / 100;
        int moduloG2 = 830000 / 100;
        int moduloD =  3725000 / 100;
        int moduloT =  1750000 / 100;


        public Flive()
        {
            InitializeComponent();
        }

        private void Bclose_Click(object sender, EventArgs e)
        {
            _thinkGearWrapper.EnableBlinkDetection(false);
            _thinkGearWrapper.Disconnect();
            //if (Breg.Text == "ferma registrazione")
                //sw.Close();
            Close();
        }

        private void Bdisatt_Click(object sender, EventArgs e)
        {
            _thinkGearWrapper.Disconnect();
            Bconn.Enabled = true;
            Bdisatt.Enabled = false;
        }

        public void CancellaRett(int col1, int h1, int col2, int h2)
        {
            System.Drawing.Graphics graphicsObj;
            graphicsObj = this.CreateGraphics();
            Pen myPenCanc = new Pen(Flive.ActiveForm.BackColor, 1);
            Brush myBrushCanc = new SolidBrush(Flive.ActiveForm.BackColor);

            Rectangle myRectangleCanc = new Rectangle(col1, h1, col2, 380); //h2
            graphicsObj.DrawRectangle(myPenCanc, myRectangleCanc);
            graphicsObj.FillRectangle(myBrushCanc, myRectangleCanc);
        }

        void _thinkGearWrapper_ThinkGearChanged(object sender, ThinkGearChangedEventArgs e)
        {
            int att, med, a1, a2, b1, b2, g1, g2, de, th, ps;
            int spess = 3;

            // update the textbox and sleep for a tiny bit
            BeginInvoke(new MethodInvoker(delegate
                {
                    //if (ora != DateTime.Now.ToLongTimeString())
                    interv++;
                    if (interv == Convert.ToUInt16(CBint.SelectedItem.ToString())) 
                    {
                        interv = 0;

                        ora = DateTime.Now.ToLongTimeString();
                        //Lora.Text = ora;

                        System.Drawing.Graphics graphicsObj;
                        graphicsObj = this.CreateGraphics();

                        if (CBatt.Checked)
                        {
                            att = (int)e.ThinkGearState.Attention;
                            if (oldVatt == -1)
                                oldVatt = att;
                            else
                            {
                                Pen myPenRed = new Pen(System.Drawing.Color.Red, spess);
                                graphicsObj.DrawLine(myPenRed, r, Patt.Top + oldVatt, r + 1, Patt.Top + att);
                                oldVatt = att;
                            }
                            med = (int)e.ThinkGearState.Meditation;
                            if (oldVmed == -1)
                                oldVmed = med;
                            else
                            {
                                Pen myPenMed = new Pen(System.Drawing.Color.Fuchsia, spess);
                                graphicsObj.DrawLine(myPenMed, r, Patt.Top + oldVmed, r + 1, Patt.Top + med);
                                oldVmed = med;
                                CBatt.Text = "att./med.:" + String.Format("{0,7:N0}", att) + String.Format("{0,7:N0}", med);
                            }
                        }

                        if (CBalfa.Checked)
                        {
                            a1 = (int)(e.ThinkGearState.Alpha1 / moduloA1);
                            if (oldVa1 == -1)
                                oldVa1 = a1;
                            else
                            {
                                Pen myPenGreen = new Pen(System.Drawing.Color.DarkGreen, spess);
                                graphicsObj.DrawLine(myPenGreen, r, Palfa.Top + oldVa1, r + 1, Palfa.Top + a1);
                                oldVa1 = a1;
                            }
                            a2 = (int)(e.ThinkGearState.Alpha2 / moduloA2);
                            if (oldVa2 == -1)
                                oldVa2 = a2;
                            else
                            {
                                Pen myPenGreen2 = new Pen(System.Drawing.Color.LightGreen, spess);
                                graphicsObj.DrawLine(myPenGreen2, r, Palfa.Top + oldVa2, r + 1, Palfa.Top + a2);
                                oldVa2 = a2;
                                CBalfa.Text = "alfa:" + String.Format("{0,7:N0}", a1) + "/" + String.Format("{0,7:N0}", a2);
                            }
                        }

                        if (CBbeta.Checked)
                        {
                            b1 = (int)(e.ThinkGearState.Beta1 / moduloB1);
                            if (oldVb1 == -1)
                                oldVb1 = b1;
                            else
                            {
                                Pen myPenB1 = new Pen(System.Drawing.Color.Purple, spess);
                                graphicsObj.DrawLine(myPenB1, r, Pbeta.Top + oldVb1, r + 1, Pbeta.Top + b1);
                                oldVb1 = b1;
                            }
                            b2 = (int)(e.ThinkGearState.Beta2 / moduloB2);
                            if (oldVb2 == -1)
                                oldVb2 = b2;
                            else
                            {
                                Pen myPenB2 = new Pen(System.Drawing.Color.Violet, spess);
                                graphicsObj.DrawLine(myPenB2, r, Pbeta.Top + oldVb2, r + 1, Pbeta.Top + b2);
                                oldVb2 = b2;
                                CBbeta.Text = "beta:" + String.Format("{0,7:N0}", b1) + "/" + String.Format("{0,7:N0}", b2);
                            }
                        }

                        if (CBgamma.Checked)
                        {
                            g1 = (int)(e.ThinkGearState.Gamma1 / moduloG1);
                            if (oldVg1 == -1)
                                oldVg1 = g1;
                            else
                            {
                                Pen myPenG1 = new Pen(System.Drawing.Color.Cyan, spess);
                                graphicsObj.DrawLine(myPenG1, r, Pgamma.Top + oldVg1, r + 1, Pgamma.Top + g1);
                                oldVg1 = g1;
                            }
                            g2 = (int)(e.ThinkGearState.Gamma2 / moduloG2);
                            if (oldVg2 == -1)
                                oldVg2 = g2;
                            else
                            {
                                Pen myPenG2 = new Pen(System.Drawing.Color.DarkBlue, spess);
                                graphicsObj.DrawLine(myPenG2, r, Pgamma.Top + oldVg2, r + 1, Pgamma.Top + g2);
                                oldVg2 = g2;
                                CBgamma.Text = "gamma:" + String.Format("{0,7:N0}", g1) + "/" + String.Format("{0,7:N0}", g2);
                            }
                        }

                        if (CBdelta.Checked)
                        {
                            de = (int)(e.ThinkGearState.Delta / moduloD);
                            if (oldVde == -1)
                                oldVde = de;
                            else
                            {
                                Pen myPenDe = new Pen(System.Drawing.Color.DarkGoldenrod, spess);
                                graphicsObj.DrawLine(myPenDe, r, Pdelta.Top + oldVg1, r + 1, Pdelta.Top + de);
                                oldVde = de;
                            }
                            th = (int)(e.ThinkGearState.Theta / moduloT);
                            if (oldVth == -1)
                                oldVth = th;
                            else
                            {
                                Pen myPenTh = new Pen(System.Drawing.Color.Gold, spess);
                                graphicsObj.DrawLine(myPenTh, r, Pdelta.Top + oldVth, r + 1, Pdelta.Top + th);
                                oldVth = th;
                                CBdelta.Text = "delta/theta:" + String.Format("{0,7:N0}", de) + "/" + String.Format("{0,7:N0}", th);
                            }
                        }

                        r++;
                        if (r > Flive.ActiveForm.Width)
                        {
                            CancellaRett(0, Patt.Top, Flive.ActiveForm.Width, Flive.ActiveForm.Height - Patt.Top);
                            r = 0;
                        }
                    } //if ora
                    //---

                    ps = (int)e.ThinkGearState.PoorSignal;
                    if (ps > 0)
                        Lpoor.ForeColor = Color.FromKnownColor(KnownColor.Red);
                    else
                        Lpoor.ForeColor = Color.FromKnownColor(KnownColor.Black);
                    Lpoor.Text = "problemi segnale: " + e.ThinkGearState.PoorSignal;

                    /*if (Breg.Text == "ferma registrazione")
                    {
                        sw.WriteLine(System.DateTime.Now.ToLongTimeString());
                        sw.WriteLine(ps);
                        if (ps > 0)
                        {
                            if (ps == 200)
                                sw.WriteLine("segnale non ottimale - probabile mancato contatto con pelle");
                            else
                                sw.WriteLine("segnale non ottimale");
                        }
                        else
                        {
                            if (CBattne.Checked)
                                sw.WriteLine("at:" + e.ThinkGearState.Attention);
                            if (CBmed.Checked)
                                sw.WriteLine("me:" + e.ThinkGearState.Meditation);
                            if (CBraw.Checked)
                                sw.WriteLine("ra:" + e.ThinkGearState.Raw);
                            if (CBalfa1.Checked)
                                sw.WriteLine("a1:" + e.ThinkGearState.Alpha1);
                            if (CBalfa2.Checked)
                                sw.WriteLine("a2:" + e.ThinkGearState.Alpha2);
                            if (CBbeta1.Checked)
                                sw.WriteLine("b1:" + e.ThinkGearState.Beta1);
                            if (CBbeta2.Checked)
                                sw.WriteLine("b2:" + e.ThinkGearState.Beta2);
                            if (CBgamma1.Checked)
                                sw.WriteLine("g1:" + e.ThinkGearState.Gamma1);
                            if (CBgamma2.Checked)
                                sw.WriteLine("g2:" + e.ThinkGearState.Gamma2);
                            if (CBdelta.Checked)
                                sw.WriteLine("de:" + e.ThinkGearState.Delta);
                            if (CBtheta.Checked)
                                sw.WriteLine("th:" + e.ThinkGearState.Theta);
                        }
                    }*/

                }));
            Thread.Sleep(10);
        }

        private void Bconn_Click(object sender, EventArgs e)
        {
            _thinkGearWrapper = new ThinkGearWrapper();

            // setup the event
            _thinkGearWrapper.ThinkGearChanged += _thinkGearWrapper_ThinkGearChanged;

            // connect to the device on the specified COM port at 57600 baud
            if (!_thinkGearWrapper.Connect(cboPort.SelectedItem.ToString(), 57600, true))
                MessageBox.Show("impossibile connettersi al mindset");
            else
            {
                Bconn.Enabled = false;
                Bdisatt.Enabled = true;
                _thinkGearWrapper.EnableBlinkDetection(true);
            }
        }

        private void Flive_Load(object sender, EventArgs e)
        {
            foreach (string port in SerialPort.GetPortNames())
                cboPort.Items.Add(port);
            cboPort.SelectedIndex = 0;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            //e.Graphics.DrawLine(myPenRed, r++, 90 + oldVatt, r, 90 + att);
        }
    }
}