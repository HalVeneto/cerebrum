namespace cerebrum
{
    partial class Flive
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Bclose = new System.Windows.Forms.Button();
            this.GBconn = new System.Windows.Forms.GroupBox();
            this.cboPort = new System.Windows.Forms.ComboBox();
            this.Lporta = new System.Windows.Forms.Label();
            this.Bdisatt = new System.Windows.Forms.Button();
            this.Bconn = new System.Windows.Forms.Button();
            this.GBvis = new System.Windows.Forms.GroupBox();
            this.CBatt = new System.Windows.Forms.CheckBox();
            this.CBalfa = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lpoor = new System.Windows.Forms.Label();
            this.Lint = new System.Windows.Forms.Label();
            this.CBint = new System.Windows.Forms.ComboBox();
            this.Pbeta = new System.Windows.Forms.Panel();
            this.Patt = new System.Windows.Forms.Panel();
            this.Palfa = new System.Windows.Forms.Panel();
            this.CBbeta = new System.Windows.Forms.CheckBox();
            this.Pgamma = new System.Windows.Forms.Panel();
            this.Pdelta = new System.Windows.Forms.Panel();
            this.CBgamma = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CBdelta = new System.Windows.Forms.CheckBox();
            this.GBconn.SuspendLayout();
            this.GBvis.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Bclose
            // 
            this.Bclose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Bclose.FlatAppearance.BorderColor = System.Drawing.Color.OrangeRed;
            this.Bclose.FlatAppearance.BorderSize = 3;
            this.Bclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bclose.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bclose.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Bclose.Location = new System.Drawing.Point(1044, 12);
            this.Bclose.Name = "Bclose";
            this.Bclose.Size = new System.Drawing.Size(75, 63);
            this.Bclose.TabIndex = 17;
            this.Bclose.Text = "chiudi";
            this.Bclose.UseVisualStyleBackColor = false;
            this.Bclose.Click += new System.EventHandler(this.Bclose_Click);
            // 
            // GBconn
            // 
            this.GBconn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.GBconn.Controls.Add(this.cboPort);
            this.GBconn.Controls.Add(this.Lporta);
            this.GBconn.Controls.Add(this.Bdisatt);
            this.GBconn.Controls.Add(this.Bconn);
            this.GBconn.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBconn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GBconn.Location = new System.Drawing.Point(3, 3);
            this.GBconn.Name = "GBconn";
            this.GBconn.Size = new System.Drawing.Size(416, 72);
            this.GBconn.TabIndex = 18;
            this.GBconn.TabStop = false;
            this.GBconn.Text = "connessione";
            // 
            // cboPort
            // 
            this.cboPort.FormattingEnabled = true;
            this.cboPort.Location = new System.Drawing.Point(101, 38);
            this.cboPort.Name = "cboPort";
            this.cboPort.Size = new System.Drawing.Size(121, 24);
            this.cboPort.TabIndex = 7;
            // 
            // Lporta
            // 
            this.Lporta.AutoSize = true;
            this.Lporta.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lporta.Location = new System.Drawing.Point(98, 19);
            this.Lporta.Name = "Lporta";
            this.Lporta.Size = new System.Drawing.Size(81, 16);
            this.Lporta.TabIndex = 6;
            this.Lporta.Text = "porte seriali:";
            // 
            // Bdisatt
            // 
            this.Bdisatt.Enabled = false;
            this.Bdisatt.Location = new System.Drawing.Point(318, 22);
            this.Bdisatt.Name = "Bdisatt";
            this.Bdisatt.Size = new System.Drawing.Size(88, 40);
            this.Bdisatt.TabIndex = 2;
            this.Bdisatt.Text = "disconnetti";
            this.Bdisatt.UseVisualStyleBackColor = true;
            this.Bdisatt.Click += new System.EventHandler(this.Bdisatt_Click);
            // 
            // Bconn
            // 
            this.Bconn.Location = new System.Drawing.Point(6, 22);
            this.Bconn.Name = "Bconn";
            this.Bconn.Size = new System.Drawing.Size(82, 40);
            this.Bconn.TabIndex = 1;
            this.Bconn.Text = "connetti";
            this.Bconn.UseVisualStyleBackColor = true;
            this.Bconn.Click += new System.EventHandler(this.Bconn_Click);
            // 
            // GBvis
            // 
            this.GBvis.Controls.Add(this.CBdelta);
            this.GBvis.Controls.Add(this.CBgamma);
            this.GBvis.Controls.Add(this.CBbeta);
            this.GBvis.Controls.Add(this.CBalfa);
            this.GBvis.Controls.Add(this.CBatt);
            this.GBvis.Location = new System.Drawing.Point(425, 3);
            this.GBvis.Name = "GBvis";
            this.GBvis.Size = new System.Drawing.Size(380, 72);
            this.GBvis.TabIndex = 23;
            this.GBvis.TabStop = false;
            this.GBvis.Text = "visualizza";
            // 
            // CBatt
            // 
            this.CBatt.AutoSize = true;
            this.CBatt.Checked = true;
            this.CBatt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBatt.ForeColor = System.Drawing.Color.Red;
            this.CBatt.Location = new System.Drawing.Point(6, 22);
            this.CBatt.Name = "CBatt";
            this.CBatt.Size = new System.Drawing.Size(69, 17);
            this.CBatt.TabIndex = 23;
            this.CBatt.Text = "att./med.";
            this.CBatt.UseVisualStyleBackColor = true;
            // 
            // CBalfa
            // 
            this.CBalfa.AutoSize = true;
            this.CBalfa.Checked = true;
            this.CBalfa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBalfa.ForeColor = System.Drawing.Color.Green;
            this.CBalfa.Location = new System.Drawing.Point(6, 45);
            this.CBalfa.Name = "CBalfa";
            this.CBalfa.Size = new System.Drawing.Size(43, 17);
            this.CBalfa.TabIndex = 25;
            this.CBalfa.Text = "alfa";
            this.CBalfa.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.CBint);
            this.panel1.Controls.Add(this.Lint);
            this.panel1.Controls.Add(this.Lpoor);
            this.panel1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Location = new System.Drawing.Point(811, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(176, 63);
            this.panel1.TabIndex = 24;
            // 
            // Lpoor
            // 
            this.Lpoor.AutoSize = true;
            this.Lpoor.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Lpoor.Location = new System.Drawing.Point(7, 10);
            this.Lpoor.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.Lpoor.Name = "Lpoor";
            this.Lpoor.Size = new System.Drawing.Size(44, 13);
            this.Lpoor.TabIndex = 17;
            this.Lpoor.Text = "segnale";
            // 
            // Lint
            // 
            this.Lint.AutoSize = true;
            this.Lint.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Lint.Location = new System.Drawing.Point(7, 40);
            this.Lint.Margin = new System.Windows.Forms.Padding(1, 0, 3, 0);
            this.Lint.Name = "Lint";
            this.Lint.Size = new System.Drawing.Size(116, 13);
            this.Lint.TabIndex = 18;
            this.Lint.Text = "intervallo da cosiderare";
            // 
            // CBint
            // 
            this.CBint.FormattingEnabled = true;
            this.CBint.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.CBint.Location = new System.Drawing.Point(129, 37);
            this.CBint.Name = "CBint";
            this.CBint.Size = new System.Drawing.Size(39, 21);
            this.CBint.TabIndex = 19;
            this.CBint.Text = "5";
            // 
            // Pbeta
            // 
            this.Pbeta.Location = new System.Drawing.Point(3, 281);
            this.Pbeta.Name = "Pbeta";
            this.Pbeta.Size = new System.Drawing.Size(1116, 2);
            this.Pbeta.TabIndex = 27;
            // 
            // Patt
            // 
            this.Patt.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.Patt.Location = new System.Drawing.Point(3, 81);
            this.Patt.Name = "Patt";
            this.Patt.Size = new System.Drawing.Size(1116, 2);
            this.Patt.TabIndex = 25;
            // 
            // Palfa
            // 
            this.Palfa.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.Palfa.Location = new System.Drawing.Point(7, 181);
            this.Palfa.Name = "Palfa";
            this.Palfa.Size = new System.Drawing.Size(1116, 2);
            this.Palfa.TabIndex = 28;
            // 
            // CBbeta
            // 
            this.CBbeta.AutoSize = true;
            this.CBbeta.Checked = true;
            this.CBbeta.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBbeta.ForeColor = System.Drawing.Color.Purple;
            this.CBbeta.Location = new System.Drawing.Point(115, 45);
            this.CBbeta.Name = "CBbeta";
            this.CBbeta.Size = new System.Drawing.Size(47, 17);
            this.CBbeta.TabIndex = 26;
            this.CBbeta.Text = "beta";
            this.CBbeta.UseVisualStyleBackColor = true;
            // 
            // Pgamma
            // 
            this.Pgamma.Location = new System.Drawing.Point(7, 381);
            this.Pgamma.Name = "Pgamma";
            this.Pgamma.Size = new System.Drawing.Size(1116, 2);
            this.Pgamma.TabIndex = 29;
            // 
            // Pdelta
            // 
            this.Pdelta.Location = new System.Drawing.Point(7, 481);
            this.Pdelta.Name = "Pdelta";
            this.Pdelta.Size = new System.Drawing.Size(1116, 2);
            this.Pdelta.TabIndex = 30;
            // 
            // CBgamma
            // 
            this.CBgamma.AutoSize = true;
            this.CBgamma.Checked = true;
            this.CBgamma.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBgamma.ForeColor = System.Drawing.Color.DarkBlue;
            this.CBgamma.Location = new System.Drawing.Point(234, 45);
            this.CBgamma.Name = "CBgamma";
            this.CBgamma.Size = new System.Drawing.Size(60, 17);
            this.CBgamma.TabIndex = 27;
            this.CBgamma.Text = "gamma";
            this.CBgamma.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "attenzione/meditazione";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "alfa 1 e 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "beta 1 e 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 386);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "gamma 1 e 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 486);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "delta e theta";
            // 
            // CBdelta
            // 
            this.CBdelta.AutoSize = true;
            this.CBdelta.Checked = true;
            this.CBdelta.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBdelta.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.CBdelta.Location = new System.Drawing.Point(234, 22);
            this.CBdelta.Name = "CBdelta";
            this.CBdelta.Size = new System.Drawing.Size(78, 17);
            this.CBdelta.TabIndex = 28;
            this.CBdelta.Text = "delta/theta";
            this.CBdelta.UseVisualStyleBackColor = true;
            // 
            // Flive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1131, 586);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Pdelta);
            this.Controls.Add(this.Pgamma);
            this.Controls.Add(this.Palfa);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.GBvis);
            this.Controls.Add(this.GBconn);
            this.Controls.Add(this.Bclose);
            this.Controls.Add(this.Patt);
            this.Controls.Add(this.Pbeta);
            this.Name = "Flive";
            this.Text = "cerebrum - rappresentazione grafica \"live\"";
            this.Load += new System.EventHandler(this.Flive_Load);
            this.GBconn.ResumeLayout(false);
            this.GBconn.PerformLayout();
            this.GBvis.ResumeLayout(false);
            this.GBvis.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Bclose;
        private System.Windows.Forms.GroupBox GBconn;
        private System.Windows.Forms.ComboBox cboPort;
        private System.Windows.Forms.Label Lporta;
        private System.Windows.Forms.Button Bdisatt;
        private System.Windows.Forms.Button Bconn;
        private System.Windows.Forms.GroupBox GBvis;
        private System.Windows.Forms.CheckBox CBatt;
        private System.Windows.Forms.CheckBox CBalfa;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox CBint;
        private System.Windows.Forms.Label Lint;
        private System.Windows.Forms.Label Lpoor;
        private System.Windows.Forms.Panel Pbeta;
        private System.Windows.Forms.Panel Patt;
        private System.Windows.Forms.Panel Palfa;
        private System.Windows.Forms.CheckBox CBbeta;
        private System.Windows.Forms.Panel Pgamma;
        private System.Windows.Forms.Panel Pdelta;
        private System.Windows.Forms.CheckBox CBgamma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox CBdelta;
    }
}