using System;
using System.Collections.Generic;
using System.Text;

namespace cerebrum
{
    class stats
    {
        public int at_min;
        public int at_max = 0;
        public long at_tot = 0;
        public int at_nr = 0;

        public int me_min;
        public int me_max = 0;
        public long me_tot = 0;
        public int me_nr = 0;

        public int a1_min;
        public int a1_max = 0;
        public long a1_tot = 0;
        public int a1_nr = 0;

        public int a2_min;
        public int a2_max = 0;
        public long a2_tot = 0;
        public int a2_nr = 0;

        public int b1_min;
        public int b1_max = 0;
        public long b1_tot = 0;
        public int b1_nr = 0;

        public int b2_min;
        public int b2_max = 0;
        public long b2_tot = 0;
        public int b2_nr = 0;

        public int g1_min;
        public int g1_max = 0;
        public long g1_tot = 0;
        public int g1_nr = 0;

        public int g2_min;
        public int g2_max = 0;
        public long g2_tot = 0;
        public int g2_nr = 0;

        public int de_min;
        public int de_max = 0;
        public long de_tot = 0;
        public int de_nr = 0;

        public int th_min;
        public int th_max = 0;
        public long th_tot = 0;
        public int th_nr = 0;
    }
}
