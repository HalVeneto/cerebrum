namespace cerebrum
{
    partial class Fgraph
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Bclose = new System.Windows.Forms.Button();
            this.flist = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.pb = new System.Windows.Forms.ProgressBar();
            this.Latt = new System.Windows.Forms.Label();
            this.Lmed = new System.Windows.Forms.Label();
            this.La1 = new System.Windows.Forms.Label();
            this.La2 = new System.Windows.Forms.Label();
            this.Lg1 = new System.Windows.Forms.Label();
            this.Lg2 = new System.Windows.Forms.Label();
            this.Lb1 = new System.Windows.Forms.Label();
            this.Lb2 = new System.Windows.Forms.Label();
            this.Ld = new System.Windows.Forms.Label();
            this.Lt = new System.Windows.Forms.Label();
            this.GBtipo = new System.Windows.Forms.GroupBox();
            this.RBlinee = new System.Windows.Forms.RadioButton();
            this.RBbarre = new System.Windows.Forms.RadioButton();
            this.Patt = new System.Windows.Forms.Panel();
            this.GBtipo.SuspendLayout();
            this.SuspendLayout();
            // 
            // Bclose
            // 
            this.Bclose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Bclose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Bclose.FlatAppearance.BorderColor = System.Drawing.Color.OrangeRed;
            this.Bclose.FlatAppearance.BorderSize = 3;
            this.Bclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bclose.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bclose.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Bclose.Location = new System.Drawing.Point(929, 18);
            this.Bclose.Name = "Bclose";
            this.Bclose.Size = new System.Drawing.Size(75, 63);
            this.Bclose.TabIndex = 17;
            this.Bclose.Text = "chiudi";
            this.Bclose.UseVisualStyleBackColor = false;
            this.Bclose.Click += new System.EventHandler(this.Bclose_Click);
            // 
            // flist
            // 
            this.flist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.flist.FullRowSelect = true;
            this.flist.GridLines = true;
            this.flist.Location = new System.Drawing.Point(104, 12);
            this.flist.MultiSelect = false;
            this.flist.Name = "flist";
            this.flist.ShowGroups = false;
            this.flist.Size = new System.Drawing.Size(262, 327);
            this.flist.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.flist.TabIndex = 20;
            this.flist.UseCompatibleStateImageBehavior = false;
            this.flist.View = System.Windows.Forms.View.Details;
            this.flist.DoubleClick += new System.EventHandler(this.flist_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "nome file";
            this.columnHeader1.Width = 256;
            // 
            // pb
            // 
            this.pb.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pb.Location = new System.Drawing.Point(0, 422);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(1016, 11);
            this.pb.TabIndex = 22;
            // 
            // Latt
            // 
            this.Latt.AutoSize = true;
            this.Latt.Location = new System.Drawing.Point(63, -1);
            this.Latt.Name = "Latt";
            this.Latt.Size = new System.Drawing.Size(39, 13);
            this.Latt.TabIndex = 23;
            this.Latt.Text = "attenz.";
            // 
            // Lmed
            // 
            this.Lmed.AutoSize = true;
            this.Lmed.Location = new System.Drawing.Point(138, -1);
            this.Lmed.Name = "Lmed";
            this.Lmed.Size = new System.Drawing.Size(46, 13);
            this.Lmed.TabIndex = 24;
            this.Lmed.Text = "meditaz.";
            // 
            // La1
            // 
            this.La1.AutoSize = true;
            this.La1.Location = new System.Drawing.Point(229, -1);
            this.La1.Name = "La1";
            this.La1.Size = new System.Drawing.Size(33, 13);
            this.La1.TabIndex = 25;
            this.La1.Text = "alfa 1";
            this.La1.Click += new System.EventHandler(this.La1_Click);
            // 
            // La2
            // 
            this.La2.AutoSize = true;
            this.La2.Location = new System.Drawing.Point(290, -1);
            this.La2.Name = "La2";
            this.La2.Size = new System.Drawing.Size(33, 13);
            this.La2.TabIndex = 26;
            this.La2.Text = "alfa 2";
            // 
            // Lg1
            // 
            this.Lg1.AutoSize = true;
            this.Lg1.Location = new System.Drawing.Point(359, -1);
            this.Lg1.Name = "Lg1";
            this.Lg1.Size = new System.Drawing.Size(50, 13);
            this.Lg1.TabIndex = 27;
            this.Lg1.Text = "gamma 1";
            // 
            // Lg2
            // 
            this.Lg2.AutoSize = true;
            this.Lg2.Location = new System.Drawing.Point(436, -1);
            this.Lg2.Name = "Lg2";
            this.Lg2.Size = new System.Drawing.Size(50, 13);
            this.Lg2.TabIndex = 28;
            this.Lg2.Text = "gamma 2";
            // 
            // Lb1
            // 
            this.Lb1.AutoSize = true;
            this.Lb1.Location = new System.Drawing.Point(521, -1);
            this.Lb1.Name = "Lb1";
            this.Lb1.Size = new System.Drawing.Size(37, 13);
            this.Lb1.TabIndex = 29;
            this.Lb1.Text = "beta 1";
            // 
            // Lb2
            // 
            this.Lb2.AutoSize = true;
            this.Lb2.Location = new System.Drawing.Point(587, -1);
            this.Lb2.Name = "Lb2";
            this.Lb2.Size = new System.Drawing.Size(37, 13);
            this.Lb2.TabIndex = 30;
            this.Lb2.Text = "beta 2";
            // 
            // Ld
            // 
            this.Ld.AutoSize = true;
            this.Ld.Location = new System.Drawing.Point(658, -1);
            this.Ld.Name = "Ld";
            this.Ld.Size = new System.Drawing.Size(30, 13);
            this.Ld.TabIndex = 31;
            this.Ld.Text = "delta";
            // 
            // Lt
            // 
            this.Lt.AutoSize = true;
            this.Lt.Location = new System.Drawing.Point(730, -1);
            this.Lt.Name = "Lt";
            this.Lt.Size = new System.Drawing.Size(31, 13);
            this.Lt.TabIndex = 32;
            this.Lt.Text = "theta";
            // 
            // GBtipo
            // 
            this.GBtipo.Controls.Add(this.RBlinee);
            this.GBtipo.Controls.Add(this.RBbarre);
            this.GBtipo.Location = new System.Drawing.Point(12, 24);
            this.GBtipo.Name = "GBtipo";
            this.GBtipo.Size = new System.Drawing.Size(86, 65);
            this.GBtipo.TabIndex = 34;
            this.GBtipo.TabStop = false;
            this.GBtipo.Text = "tipo di grafico";
            // 
            // RBlinee
            // 
            this.RBlinee.AutoSize = true;
            this.RBlinee.Location = new System.Drawing.Point(6, 42);
            this.RBlinee.Name = "RBlinee";
            this.RBlinee.Size = new System.Drawing.Size(56, 17);
            this.RBlinee.TabIndex = 2;
            this.RBlinee.TabStop = true;
            this.RBlinee.Text = "a linee";
            this.RBlinee.UseVisualStyleBackColor = true;
            // 
            // RBbarre
            // 
            this.RBbarre.AutoSize = true;
            this.RBbarre.Checked = true;
            this.RBbarre.Location = new System.Drawing.Point(6, 19);
            this.RBbarre.Name = "RBbarre";
            this.RBbarre.Size = new System.Drawing.Size(58, 17);
            this.RBbarre.TabIndex = 1;
            this.RBbarre.TabStop = true;
            this.RBbarre.Text = "a barre";
            this.RBbarre.UseVisualStyleBackColor = true;
            // 
            // Patt
            // 
            this.Patt.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.Patt.Location = new System.Drawing.Point(-112, 15);
            this.Patt.Name = "Patt";
            this.Patt.Size = new System.Drawing.Size(1116, 2);
            this.Patt.TabIndex = 35;
            // 
            // Fgraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.Bclose;
            this.ClientSize = new System.Drawing.Size(1016, 433);
            this.Controls.Add(this.Patt);
            this.Controls.Add(this.GBtipo);
            this.Controls.Add(this.Lt);
            this.Controls.Add(this.Ld);
            this.Controls.Add(this.Lb2);
            this.Controls.Add(this.Lb1);
            this.Controls.Add(this.Lg2);
            this.Controls.Add(this.Lg1);
            this.Controls.Add(this.La2);
            this.Controls.Add(this.La1);
            this.Controls.Add(this.Lmed);
            this.Controls.Add(this.Latt);
            this.Controls.Add(this.pb);
            this.Controls.Add(this.flist);
            this.Controls.Add(this.Bclose);
            this.KeyPreview = true;
            this.Name = "Fgraph";
            this.Text = "cerebrum - grafici";
            this.Load += new System.EventHandler(this.Fgraph_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Fgraph_Paint);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Fgraph_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Fgraph_KeyUp);
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Fgraph_PreviewKeyDown);
            this.GBtipo.ResumeLayout(false);
            this.GBtipo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Bclose;
        private System.Windows.Forms.ListView flist;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ProgressBar pb;
        private System.Windows.Forms.Label Latt;
        private System.Windows.Forms.Label Lmed;
        private System.Windows.Forms.Label La1;
        private System.Windows.Forms.Label La2;
        private System.Windows.Forms.Label Lg1;
        private System.Windows.Forms.Label Lg2;
        private System.Windows.Forms.Label Lb1;
        private System.Windows.Forms.Label Lb2;
        private System.Windows.Forms.Label Ld;
        private System.Windows.Forms.Label Lt;
        private System.Windows.Forms.GroupBox GBtipo;
        private System.Windows.Forms.RadioButton RBlinee;
        private System.Windows.Forms.RadioButton RBbarre;
        private System.Windows.Forms.Panel Patt;
    }
}