using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace cerebrum
{
    public partial class Fstat : Form
    {
        public Fstat()
        {
            InitializeComponent();
        }

        private void Fstat_Activated(object sender, EventArgs e)
        {
          
        }

        private void Bclose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Fstat_Load(object sender, EventArgs e)
        {
            int x;

            vlist.Visible=false; flist.Visible=true;
            string[] filePaths = Directory.GetFiles(@".", "*.cdat", SearchOption.AllDirectories);

            for (x = 0; x < filePaths.Length; x++)
                flist.Items.Add(filePaths[x]);
        }

        private void MostraVoce(ListViewItem itm, String des, int min, long max, long tot, long nr)
        {
            itm.Text = des;
            itm.SubItems.Add(String.Format("{0,10:N0}", min));
            itm.SubItems.Add(String.Format("{0,10:N0}", max));
            if (nr > 0)
                itm.SubItems.Add(String.Format("{0,10:N0}", tot / nr));
        }

        private void flist_DoubleClick(object sender, EventArgs e)
        {
            String fn, s, ss, line;
            int v, totr = 0;
            bool ok;

            stats st = new stats();
            st.at_min = int.MaxValue;
            st.me_min = int.MaxValue;
            st.a1_min = int.MaxValue;
            st.a2_min = int.MaxValue;
            st.b1_min = int.MaxValue;
            st.b2_min = int.MaxValue;
            st.g1_min = int.MaxValue;
            st.g2_min = int.MaxValue; 
            st.de_min = int.MaxValue;
            st.th_min = int.MaxValue;

            flist.Visible = false;
            fn = flist.SelectedItems[0].Text;
            System.IO.StreamReader srtmp = new System.IO.StreamReader(fn);
            totr = 0;
            while ((line = srtmp.ReadLine()) != null)
                totr++;
            srtmp.Close();
            pb.Minimum = 0; pb.Maximum = totr; pb.Value = 0;
            System.IO.StreamReader sr = new System.IO.StreamReader(fn);
            totr = 0;
            while ((line = sr.ReadLine()) != null)
            {
                //MessageBox.Show(line, "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                ok = line.Trim() != "";
                if (ok)
                {
                    ok = line.Length > 2;
                    if (ok) 
                        ok = line.Substring(2, 1) == ":";
                    if (ok)
                        if (line.Length >= 6)
                            ok = line.Substring(5, 1) != ":";
                }
                //if ( && line.Length > 2 && line.Substring(2, 1) == ":" && line.Substring(5,1) != ":") //5,1: � un orario
                if (ok)
                {
                    s = line.Substring(0, 2);
                    ss = line.Substring(3, line.Length - 3);
                    v = System.Convert.ToInt32(ss);
                    switch (s)
                    {
                        case "at":
                            st.at_tot += v;
                            st.at_nr++;
                            if (v < st.at_min)
                                st.at_min = v;
                            if (v > st.at_max)
                                st.at_max = v;
                            break;
                        case "me":
                            st.me_tot += v;
                            st.me_nr++;
                            if (v < st.me_min)
                                st.me_min = v;
                            if (v > st.me_max)
                                st.me_max = v;
                            break;
                        case "a1":
                            st.a1_tot += v;
                            st.a1_nr++;
                            if (v < st.a1_min)
                                st.a1_min = v;
                            if (v > st.a1_max)
                                st.a1_max = v;
                            break;
                        case "a2":
                            st.a2_tot += v;
                            st.a2_nr++;
                            if (v < st.a2_min)
                                st.a2_min = v;
                            if (v > st.a2_max)
                                st.a2_max = v;
                            break;
                        case "b1":
                            st.b1_tot += v;
                            st.b1_nr++;
                            if (v < st.b1_min)
                                st.b1_min = v;
                            if (v > st.b1_max)
                                st.b1_max = v;
                            break;
                        case "b2":
                            st.b2_tot += v;
                            st.b2_nr++;
                            if (v < st.b2_min)
                                st.b2_min = v;
                            if (v > st.b2_max)
                                st.b2_max = v;
                            break;
                        case "g1":
                            st.g1_tot += v;
                            st.g1_nr++;
                            if (v < st.g1_min)
                                st.g1_min = v;
                            if (v > st.g1_max)
                                st.g1_max = v;
                            break;
                        case "g2":
                            st.g2_tot += v;
                            st.g2_nr++;
                            if (v < st.g2_min)
                                st.g2_min = v;
                            if (v > st.g2_max)
                                st.g2_max = v;
                            break;
                        case "de":
                            st.de_tot += v;
                            st.de_nr++;
                            if (v < st.de_min)
                                st.de_min = v;
                            if (v > st.de_max)
                                st.de_max = v;
                            break;
                        case "th":
                            st.th_tot += v;
                            st.th_nr++;
                            if (v < st.th_min)
                                st.th_min = v;
                            if (v > st.th_max)
                                st.th_max = v;
                            break;
                    }
                    //pb.Value = ++totr;
                } //if
                pb.Value = ++totr;
            } //while
            pb.Value = pb.Maximum;
            sr.Close();
            pb.Hide();

            vlist.Items.Clear();

            // Set the view to show details.
            vlist.View = View.Details;
            // Allow the user to edit item text.
            vlist.LabelEdit = true;
            // Allow the user to rearrange columns.
            vlist.AllowColumnReorder = true;
            // Display check boxes.
            vlist.CheckBoxes = false;
            // Select the item and subitems when selection is made.
            vlist.FullRowSelect = true;
            // Display grid lines.
            vlist.GridLines = true;
            // Sort the items in the list in ascending order.
            //vlist.Sorting = SortOrder.Ascending;

            ListViewItem item1 = new ListViewItem();
            /*item1.Text = "attenzione";
            item1.SubItems.Add(String.Format("{0,10:N0}", st.at_min));
            item1.SubItems.Add(String.Format("{0,10:N0}", st.at_max));
            item1.SubItems.Add(String.Format("{0,10:N0}", st.at_tot / st.at_nr));*/
            MostraVoce(item1, "attenzione", st.at_min, st.at_max, st.at_tot, st.at_nr);

            ListViewItem item2 = new ListViewItem();
            item2.Text = "meditazione";
            item2.SubItems.Add(String.Format("{0,10:N0}", st.me_min));
            item2.SubItems.Add(String.Format("{0,10:N0}", st.me_max));
            item2.SubItems.Add(String.Format("{0,10:N0}", st.me_tot / st.me_nr));

            ListViewItem item3 = new ListViewItem();
            item3.Text = "alfa 1";
            item3.SubItems.Add(String.Format("{0,10:N0}", st.a1_min));
            item3.SubItems.Add(String.Format("{0,10:N0}", st.a1_max));
            item3.SubItems.Add(String.Format("{0,10:N0}", st.a1_tot / st.a1_nr));

            ListViewItem item4 = new ListViewItem();
            item4.Text = "alfa 2";
            item4.SubItems.Add(String.Format("{0,10:N0}", st.a2_min));
            item4.SubItems.Add(String.Format("{0,10:N0}", st.a2_max));
            item4.SubItems.Add(String.Format("{0,10:N0}", st.a2_tot / st.a2_nr));

            ListViewItem item5 = new ListViewItem();
            item5.Text = "beta 1";
            item5.SubItems.Add(String.Format("{0,10:N0}", st.b1_min));
            item5.SubItems.Add(String.Format("{0,10:N0}", st.b1_max));
            item5.SubItems.Add(String.Format("{0,10:N0}", st.b1_tot / st.b1_nr));

            ListViewItem item6 = new ListViewItem();
            item6.Text = "beta 2";
            item6.SubItems.Add(String.Format("{0,10:N0}", st.b2_min));
            item6.SubItems.Add(String.Format("{0,10:N0}", st.b2_max));
            item6.SubItems.Add(String.Format("{0,10:N0}", st.b2_tot / st.b2_nr));

            ListViewItem item7 = new ListViewItem();
            item7.Text = "gamma 1";
            item7.SubItems.Add(String.Format("{0,10:N0}", st.g1_min));
            item7.SubItems.Add(String.Format("{0,10:N0}", st.g1_max));
            item7.SubItems.Add(String.Format("{0,10:N0}", st.g1_tot / st.g1_nr));

            ListViewItem item8 = new ListViewItem();
            item8.Text = "gamma 2";
            item8.SubItems.Add(String.Format("{0,10:N0}", st.g2_min));
            item8.SubItems.Add(String.Format("{0,10:N0}", st.g2_max));
            item8.SubItems.Add(String.Format("{0,10:N0}", st.g2_tot / st.g2_nr));

            ListViewItem item9 = new ListViewItem();
            item9.Text = "delta";
            item9.SubItems.Add(String.Format("{0,10:N0}", st.de_min));
            item9.SubItems.Add(String.Format("{0,10:N0}", st.de_max));
            item9.SubItems.Add(String.Format("{0,10:N0}", st.de_tot / st.de_nr));

            ListViewItem item10 = new ListViewItem();
            item10.Text = "theta";
            //item10.SubItems.Add(System.Convert.ToString(st.th_min));
            item10.SubItems.Add(String.Format("{0,10:N0}", st.th_min));
            item10.SubItems.Add(String.Format("{0,10:N0}", st.th_max));
            item10.SubItems.Add(String.Format("{0,10:N0}", st.th_tot / st.th_nr));
          
            vlist.Columns.Add("voce", 80, HorizontalAlignment.Left);
            vlist.Columns.Add("min.", 60, HorizontalAlignment.Right);
            vlist.Columns.Add("max", 70, HorizontalAlignment.Right);
            vlist.Columns.Add("media", 60, HorizontalAlignment.Right);

            vlist.Items.AddRange(new ListViewItem[] { item1, item2, item3, item4, item5, item6, item7, item8, item9, item10 });



            /*vlist.Items.Add("meditazione", 0);
            vlist.Items.Add(System.Convert.ToString(st.me_min), 1);
            vlist.Items.Add(System.Convert.ToString(st.me_max), 2);*/

            /*vlist.Columns[0].Text = "attenzione:";
            vlist.Columns[1].Text = System.Convert.ToString(min);
            vlist.Columns[2].Text = System.Convert.ToString(max);*/
            vlist.Visible = true;
        } //dblclick
    } //fstat
}