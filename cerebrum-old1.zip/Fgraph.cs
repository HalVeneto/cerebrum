using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace cerebrum
{
    public partial class Fgraph : Form
    {
        public Fgraph()
        {
            InitializeComponent();
        }

        private void Bclose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}