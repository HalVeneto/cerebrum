using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace cerebrum
{
    public partial class Fcsv : Form
    {
        public Fcsv()
        {
            InitializeComponent();
        }

        private void flist_DoubleClick(object sender, EventArgs e)
        {
            String fn, s, ss, line;
            int v, totr = 0;
            bool eof, ok;

            //flist.Visible = false;
            fn = flist.SelectedItems[0].Text;
            System.IO.StreamReader srIn = new System.IO.StreamReader(fn);
            System.IO.StreamWriter srOut = new System.IO.StreamWriter("out.csv");
            totr = 0;
            while ((line = srIn.ReadLine()) != null) {
                totr++;

                ok = line.Trim() != "";
                if (ok)
                {
                    ok = line.Length > 2;
                    if (ok)
                        ok = line.Substring(2, 1) == ":";
                    if (ok)
                        if (line.Length >= 6)
                            ok = line.Substring(5, 1) != ":";
                    if (ok)
                    {
                        s = line.Substring(0, 3);
                        ss = line.Substring(3, line.Length - 3);
                        v = System.Convert.ToInt32(ss);
                        srOut.Write(v);
                    
                        eof = false;
                        if (line.Length > 2)
                        {
                            if (s == "th:")
                            {
                                srOut.WriteLine();
                                eof = true;
                            }
                        }
                        if (!eof)
                            srOut.Write(";");
                    } //if ok
                } //if ok
            } //while
            srIn.Close();
            srOut.Close();
            MessageBox.Show("esportazione terminata.\nCreato file 'out.csv'", "informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Bclose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Fcsv_Load(object sender, EventArgs e)
        {
            int x;

            flist.Visible = true;
            string[] filePaths = Directory.GetFiles(@".", "*.cdat", SearchOption.AllDirectories);

            for (x = 0; x < filePaths.Length; x++)
                flist.Items.Add(filePaths[x]);
        }
    }
}